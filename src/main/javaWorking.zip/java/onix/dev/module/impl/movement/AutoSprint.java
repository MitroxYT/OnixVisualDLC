package onix.dev.module.impl.movement;

import com.google.common.eventbus.Subscribe;
import onix.dev.event.impl.game.EventUpdate;
import onix.dev.module.api.Category;
import onix.dev.module.api.Function;
import onix.dev.module.api.ModuleInfo;

@ModuleInfo(name = "AutoSprint", category = Category.MOVEMENT, desc = "бежать бежать бежать бежать бежать бежать сасать бежать бежать бежать бежать бежать бежать бежать бежать бежать бежать")
public class AutoSprint extends Function {

    public AutoSprint() {

    }

    @Subscribe
    public void onUpdate(EventUpdate event) {
        if (fullNullCheck()) return;
        mc.options.keySprint.setDown(true);
    }
}
